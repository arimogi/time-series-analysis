library(tseries)
library(forecast)
library(lmtest)
library(nortest)
library(MASS)
library(stargazer)

setwd("/Users/yunita/Documents/STUDY/KULIAH/TIME SERIES")
data <- read.csv("8.6.csv")
Nilai <- data$Price
Bulan <- data$Year
head(Nilai)

ts.plot(Nilai)

#stasioner dalam varians 
#BoxCox.lambda(Nilai)
#u1 <- boxcox(lm(Nilai ~ 1))
#lambda <- u1$x[which.max(u1$y)]
#data_var <- (Nilai^lambda - 1)/lambda

adf.test(Nilai, k=12)
par(mfrow = c(1, 2))
acf(Nilai, lag.max = 90)
pacf(Nilai, lag.max = 90)

# Differencing
differencing <- diff(Nilai, differences = 1)
adf.test(differencing)
ts.plot(differencing)

par(mfrow = c(1, 2))
acf(differencing, lag.max = 50)
pacf(differencing, lag.max = 50)

# Modeling ARIMA seasonal lag 12 diff 1
diffnonmus_mus12 <- diff(differencing, lag=12)
diffnonmus_mus12

ts.plot(diffnonmus_mus12)

par(mfrow = c(1, 2))
acf(diffnonmus_mus12, lag.max = 50)
pacf(diffnonmus_mus12, lag.max = 50)

#ARIMA (0,1,1)(1,1,0)12
Arima.1 <- arima(Nilai, order = c(0, 1, 1), seasonal = list(order=c(1,1,0), period=12))
summary(Arima.1)

# Uji Signifikansi Parameter
coeftest(Arima.1)

#pengujian residual apakah white noise
Box.test(Arima.1$residuals, type = "Ljung")
residual1 <- Arima.1$residuals
residual1
ts.plot(residual1)

par(mfrow = c(1, 2))
acf(residual1, lag.max = 50)
pacf(residual1, lag.max = 50)

#uji normalitas
shapiro.test(Arima.1$residuals)

forecasting <-forecast(Nilai, model=Arima.1, h=12)
forecasting

plot(forecasting, main = "Hasil peramalan")


accuracy(Arima.1)
AIC(Arima.1)

sst <- sum((Nilai - mean(Nilai))^2)
sse <- sum(Arima.1$residuals^2)
r_square <- 1- (sse / sst)
print(r_square)

Nilai <- data$Price
fit.data=fitted(Arima.1)
par(mfrow=c(1,1))
ts.plot(Nilai)
lines(fit.data, col="red")

