library(tseries)
library(forecast)
library(lmtest)
library(nortest)
library(MASS)
library(stargazer)

setwd("/Users/yunita/Documents/STUDY/KULIAH/TIME SERIES")
data <- read.csv("7.13.csv")
Nilai <- data$Production
Tahun <- data$Year

# Plot time series
ts.plot(Nilai, xlab="Tahun", ylab="Nilai", main="Grafik Produksi Pertahun")
rata_rata <- mean(Nilai)
abline(h = rata_rata, col = "red")

#transformasi dalam varians
BoxCox.lambda(Nilai)
u1 <- boxcox(lm(Nilai ~ 1))
#lambda <- u1$x[which.max(u1$y)]
data_var <- (Nilai^BoxCox.lambda(Nilai) - 1) / BoxCox.lambda(Nilai) #transformasi boxcox
ts.plot(data_var)

BoxCox.lambda(data_var)

# Cek Stasioner dalam Mean
adf.test(data_var)

par(mfrow = c(1, 2))
acf(data_var, lag.max = 30)
pacf(data_var, lag.max = 30)

# Differencing
differencing <- diff(data_var, differences = 1)
adf.test(differencing)
ts.plot(differencing)

par(mfrow = c(1, 2))
acf(differencing, lag.max = 30)
pacf(differencing, lag.max = 30)

# Modeling ARIMA
auto.arima(Nilai)
Arima.1 <- arima(Nilai, order = c(0, 1, 0), method = "ML")

# Uji Signifikansi Parameter
coeftest(Arima.1)

#pengujian residual apakah white noise
Box.test(Arima.1$residuals, type = "Ljung")

#uji normalitas
shapiro.test(Arima.1$residuals)

forecasting <-forecast(Nilai, model=Arima.1, h=4)
forecasting

plot(forecasting, main = "Hasil peramalan")


accuracy(Arima.1)
AIC(Arima.1)

sst <- sum((Nilai - mean(Nilai))^2)
sse <- sum(Arima.1$residuals^2)
r_square <- 1- (sse / sst)
print(r_square)

