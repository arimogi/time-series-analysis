library(tseries)
library(forecast)
library(lmtest)
library(nortest)
library(MASS)
library(stargazer)
library(goftest)

setwd("/Users/yunita/Documents/STUDY/KULIAH/TIME SERIES")
data <- read.csv("6.2a.csv")
Nilai <- data$Value


# Plot time series
ts.plot(Nilai)
rata_rata <- mean(Nilai)
abline(h = rata_rata, col = "red")

# Cek Stasioner dalam Varians
#data_trans <- Nilai + abs(min(Nilai)) + 1 #menambahkan suatu konstanta (biasanya nilai terkecil plus sedikit margin) untuk membuat semua data positif sebelum melakukan transformasi
adf.test(Nilai)
par(mfrow = c(1, 2))
acf(Nilai, lag.max = 46)
pacf(Nilai, lag.max = 46)

differencing <- diff(Nilai, differences = 1)
adf.test(differencing)
ts.plot(differencing)

par(mfrow = c(1, 2))
acf(differencing, lag.max = 46)
pacf(differencing, lag.max = 46)

#BoxCox.lambda(differencing)

#data_trans <- Nilai + abs(min(Nilai)) + 1
#BoxCox.lambda(data_trans)
#u1 <- boxcox(lm(data_trans ~ 1))
#lambda <- u1$x[which.max(u1$y)]


# Modeling ARIMA ([1,7],1,[1,3]) dan ([1,7],1,3)
auto.arima(Nilai)
Arima.1 <- arima(Nilai, order = c(7,1,3), fixed = c(NA, rep(0,5), NA, NA, 0, NA), transform.pars = FALSE)
Arima.2 <- arima(Nilai, order = c(7,1,1), fixed = c(NA, rep(0,5), NA, NA), transform.pars = FALSE)
Arima.3 <- arima(Nilai, order = c(1,1,1))
Arima.4 <- arima(Nilai, order = c(1,1,0))
Arima.5 <- arima(Nilai, order = c(0, 1, 1), seasonal = list(order=c(1,0,0), period=7))
summary(Arima.1)
summary(Arima.2)
summary(Arima.3)
summary(Arima.4)
summary(Arima.5)
# Uji Signifikansi Parameter
coeftest(Arima.1)
coeftest(Arima.2)
coeftest(Arima.3)
coeftest(Arima.4)
coeftest(Arima.5)

#pengujian residual apakah white noise
Box.test(Arima.3$residuals, type = "Ljung")

residual1 <- Arima.3$residuals
residual1
ts.plot(residual1)

par(mfrow = c(1, 2))
acf(residual1, lag.max = 46)
pacf(residual1, lag.max = 46)
ks.test(residual1,"dunif")

#uji normalitas
shapiro.test(Arima.3$residuals)

forecasting <-forecast(Nilai, model=Arima.3, h=20)
forecasting

#forecast data
fitted_values <- fitted(Arima.3)
fitted_values

plot(fitted_values, main = "Hasil peramalan")

accuracy(Arima.3)
AIC(Arima.3)

sst <- sum((Nilai - mean(Nilai))^2)
sse <- sum(Arima.3$residuals^2)
r_square <- 1- (sse / sst)
print(r_square)

Nilai <- data$Value
fit.data=fitted(Arima.3)
par(mfrow=c(1,1))
ts.plot(Nilai)
lines(fit.data, col="red")

