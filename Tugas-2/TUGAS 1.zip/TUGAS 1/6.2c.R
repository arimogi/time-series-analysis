library(tseries)
library(forecast)
library(lmtest)
library(nortest)
library(MASS)
library(stargazer)

setwd("/Users/yunita/Documents/STUDY/KULIAH/TIME SERIES")
data <- read.csv("6.2c.csv")
Nilai <- data$Nilai


# Plot time series
ts.plot(Nilai)
rata_rata <- mean(Nilai)
abline(h = rata_rata, col = "red")

# Cek Stasioner dalam Varians
#data_trans <- Nilai + abs(min(Nilai)) + 1 #menambahkan suatu konstanta (biasanya nilai terkecil plus sedikit margin) untuk membuat semua data positif sebelum melakukan transformasi
u1 <- boxcox(lm(Nilai ~1))
lambda <- u1$x[which.max(u1$y)]
lambda

# Cek Stasioner dalam Mean
adf.test(Nilai)

par(mfrow = c(1, 2))
acf(Nilai, lag.max = 46)
pacf(Nilai, lag.max = 46)

# Differencing
differencing <- diff(Nilai, differences = 1)
adf.test(differencing)
ts.plot(differencing)

par(mfrow = c(1, 2))
acf(differencing, lag.max = 20)
pacf(differencing, lag.max = 25)

# Modeling ARIMA
Arima.1 <- arima(Nilai, order = c(0,1,1), method = "ML")
Arima.2 <- arima(Nilai, order = c(1,1,0), method = "ML")
Arima.3 <- arima(Nilai, order = c(1,1,1), method = "ML")
#Arima.4 <- arima(Nilai, order = c(2,1,1), fixed = c(NA, rep(0,1), NA, NA), transform.pars = FALSE)


# Uji Signifikansi Parameter
coeftest(Arima.1)
coeftest(Arima.2)
coeftest(Arima.3)


#pengujian residual apakah white noise
Box.test(Arima.2$residuals, type = "Ljung")

#uji normalitas
shapiro.test(Arima.2$residuals)

forecasting <-forecast(Nilai, model=Arima.2, h=20)
forecasting

#forecast data
fitted_values <- fitted(Arima.2)
fitted_values

plot(fitted_values, main = "Hasil peramalan")

accuracy(Arima.2)
AIC(Arima.2)

sst <- sum((Nilai - mean(Nilai))^2)
sse <- sum(Arima.2$residuals^2)
r_square <- 1- (sse / sst)
print(r_square)

Nilai <- data$Nilai
fit.data=fitted(Arima.2)
par(mfrow=c(1,1))
ts.plot(Nilai)
lines(fit.data, col="red")

